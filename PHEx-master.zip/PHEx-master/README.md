# Prodigy Hacking Extension (PHEx)

Combined with [Redirector](https://github.com/Prodigy-Hacking/Redirector) to inject modified game files into Prodigy.

Made of the Redirector extension, no-csp, and a little extra spice ;)

## [Usage](https://github.com/Prodigy-Hacking/ProdigyMathGameHacking/wiki/How-to-install-hacks)

## Building

```cmd
node build.js
```

## Credit

Originally created by Rus, maintained by PatheticMustan.
